# Description
This mod allows you to change the maximum amount of players allowed on the server.

Recommended to also use [Data Rate Modifier](https://valheim.thunderstore.io/package/Valdream/Data_Rate_Modifier/).

# Configuration
Configuration file generated on first run.

Default player limit is 10 which is the game's default. Change the value in the configuration file and restart the server to enable the change.

# Installation
* Ensure BepInEx is installed
* Download this mod and put it into the BepInEx/plugins folder

Enjoy the game!