# Activation - Personal

## Unity licensing

We do everything we can to make our software available to as many people as possible and give it away free of charge to many of you. However, to allow us to continue to maintain and develop the Unity engine to a high professional standard, we charge a license fee to some of our users.

### If you work for a company with gross annual revenue of less than USD100,000 in the previous fiscal year
Unity is available free of charge.

### If you work for a charity, educational institution or other non-commercial entity with gross annual revenue of less than USD100,000 in the previous fiscal year
Unity is available free of charge.

### If you’re a hobbyist and you’re not using Unity for commercial work
Unity is available free of charge.

### If you’re a freelancer using Unity for commercial projects and your gross annual revenue for the previous fiscal year was less than USD100,000
Unity is available free of charge.

### If you work for an organization or company with gross annual revenue of more than USD100,000 in the previous fiscal year
Licensing fees apply. Please purchase the Pro version of our software: https://store.unity.com/

For more precise information, see the Unity EULA: https://unity3d.com/legal/terms-of-service
